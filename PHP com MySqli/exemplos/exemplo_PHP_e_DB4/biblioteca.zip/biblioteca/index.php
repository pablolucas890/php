 <html>
 <HEAD>
 <meta charset="utf-8"/>
 <title>
Login
 </title>
 </HEAD>
 <body>
<form method="post" action="login.php">
Login:
<input type="text" name="login">
<br>
<br>
Senha
<input type="text" name="senha">
<br>
<br>
<input type="submit" name="submit" value="Enviar"/>
 </body>
 </html>