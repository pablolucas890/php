 <html>
 <HEAD>
 <meta charset="utf-8"/>
 <title>
Login
 </title>
 </HEAD>
 <body>
<form method="post" action="inseredados.php">
Titulo:
<input type="text" name="titulo">
<br>
<br>
Autor:
<input type="text" name="autor">
<br>
<br>
Ano:
<input type="text" name="ano">
<br>
<br>
<input type="submit" name="submit" value="Enviar"/>
 </body>
 </html>